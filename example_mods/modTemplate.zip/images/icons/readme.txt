Put your custom character icons here!
The image resolution must have a minimal of 450x150