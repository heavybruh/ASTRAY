Put your custom songs and charts here
It should be a folder with your custom song's name.
Inside of it should include two song files:
"Inst.ogg" and "Voices.ogg"
with the same folder add your chart (and lua if you wanted to add that) into the song
such as:
"test.json"
"test-easy.json"
"test-hard.json"